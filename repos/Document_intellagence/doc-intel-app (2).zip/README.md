# Document Intelligence Starter Repo

## Setup

1. Install Ollama and pull Mistral or LLaMA3 models:
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull mistral
ollama run mistral
```

2. Start Qdrant for vector search:
```bash
docker run -p 6333:6333 qdrant/qdrant
```

3. Install Python dependencies:
```bash
pip install -r requirements.txt
```

4. Start FastAPI backend:
```bash
uvicorn backend.main:app --reload
```

5. Start Streamlit frontend:
```bash
streamlit run frontend/app.py
```

## Usage

- Upload invoices or documents in the Streamlit UI to extract data using your local LLM.
- Search indexed documents using the search box.

## Auth

- Use token `my-secret-token` in header `x-token`.