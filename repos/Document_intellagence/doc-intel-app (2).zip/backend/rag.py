def answer_question(query):
    # Simplified dummy response for demo
    return f"Answer to '{query}' based on stored documents."