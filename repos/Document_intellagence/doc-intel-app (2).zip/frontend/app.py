import streamlit as st
import requests

API_URL = "http://localhost:8000"
API_TOKEN = "my-secret-token"

st.title("Document Intelligence")

doc_type = st.selectbox("Select Document Type", ["Invoice"])

uploaded_file = st.file_uploader("Upload Document", type=["pdf", "png", "jpg"])

if uploaded_file:
    st.info("Extracting...")
    files = {"file": uploaded_file.getvalue()}
    headers = {"x-token": API_TOKEN}
    response = requests.post(f"{API_URL}/extract/invoice/", files=files, headers=headers)
    st.json(response.json())

query = st.text_input("Search documents")
if query:
    headers = {"x-token": API_TOKEN}
    response = requests.get(f"{API_URL}/search/", params={"query": query}, headers=headers)
    st.write(response.json().get("answer"))