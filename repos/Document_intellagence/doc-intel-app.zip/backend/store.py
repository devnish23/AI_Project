import sqlite3
import json

def store_doc(doc_type, content):
    conn = sqlite3.connect('documents.db')
    c = conn.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS documents (id INTEGER PRIMARY KEY, type TEXT, content TEXT)')
    c.execute('INSERT INTO documents (type, content) VALUES (?, ?)', (doc_type, json.dumps(content)))
    conn.commit()
    conn.close()