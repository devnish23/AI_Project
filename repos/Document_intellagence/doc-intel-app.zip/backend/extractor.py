import requests

def extract_invoice_data(file_bytes):
    text = "Extracted OCR text from file here"
    # Simplified local LLM call (stub)
    prompt = f"Extract key fields from invoice:\n{text}\nReturn JSON."
    response = requests.post("http://localhost:11434/api/generate", json={
        "model": "mistral",
        "prompt": prompt,
        "stream": False
    })
    return response.json().get("response", {})