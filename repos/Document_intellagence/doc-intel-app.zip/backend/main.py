from fastapi import FastAPI, File, UploadFile, Depends, HTTPException, Header
from backend.auth import verify_token
from backend.extractor import extract_invoice_data
from backend.store import store_doc
from backend.rag import answer_question

app = FastAPI()

@app.post("/extract/invoice/")
async def extract_invoice(file: UploadFile = File(...), token: str = Depends(verify_token)):
    content = await file.read()
    data = extract_invoice_data(content)
    store_doc("invoice", data)
    return {"extracted_data": data}

@app.get("/search/")
async def search_docs(query: str, token: str = Depends(verify_token)):
    answer = answer_question(query)
    return {"answer": answer}